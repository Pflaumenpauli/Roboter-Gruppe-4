package parkingRobot.hsamr0;

public class pid {
	
		double Kp=0.2 ;
		double Ki=0.0007;
		double Kd=0;
		//Führungsgröße
		double w=0;
		//Regeldifferenz
		double e=0;
		 //Reglerausgangsgröße
	    double y=0;
		//Regeldifferenz beim vorherigen durchlauf des Threads
	    double eLast=0;
	    //Wert des Integrals  von e(t)
	    double eInt=0;
	    //Wert des Differntials de/dt
	    double eDif=0;
	    //Hilfsvariable zum berechnen der Zeitdifferenz zwischen zwei Thread-Durchl�ufen
	    long T=0;
	    //Hilfsvariable zum speichern der Systemzeit
	    long tsys=0;
	    //Zeitdifferenz
	    long dTime=0;
	    
	    
	    public double getY(double x)
	    {
	    	tsys=System.currentTimeMillis();
	    	T=tsys;
	    	dTime=T-tsys;
	    	eLast=e;
			e=w-x;
			eInt=eInt+(dTime*(e+eLast)/(double)2);
	    	
			return y ;
	    	
	    }
	}



